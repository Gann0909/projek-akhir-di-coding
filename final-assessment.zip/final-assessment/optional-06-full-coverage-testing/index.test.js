// index.test.js
import assert from 'node:assert';
import sum from './index.js';

// 1. Menguji penjumlahan dua angka positif
assert.strictEqual(sum(3, 5), 8, 'Penjumlahan dari 3 + 5 seharusnya 8');

// 2. Menguji dua angka negatif - harus kembali 0
assert.strictEqual(sum(-3, -5), 0, 'Penjumlahan dari -3 + -5 seharusnya 0');

// 3. Menguji satu angka positif dan satu negatif - harus kembali 0
assert.strictEqual(sum(5, -3), 0, 'Penjumlahan dari 5 + (-3) seharusnya 0');

// 4. Menguji angka nol
assert.strictEqual(sum(0, 0), 0, 'Penjumlahan dari 0 + 0 seharusnya 0');
assert.strictEqual(sum(5, 0), 5, 'Penjumlahan dari 5 + 0 seharusnya 5');

// 5. Menguji jika argumen bukan angka - harus kembali 0
assert.strictEqual(sum('5', 3), 0, 'Penjumlahan dengan argumen bukan angka seharusnya 0');
assert.strictEqual(sum(5, '3'), 0, 'Penjumlahan dengan argumen bukan angka seharusnya 0');
assert.strictEqual(sum('5', '3'), 0, 'Penjumlahan dengan kedua argumen bukan angka seharusnya 0');
