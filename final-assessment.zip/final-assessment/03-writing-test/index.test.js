
import assert from 'node:assert';
import { test } from 'node:test';
import { sum } from './index.js';

// Menulis test cases
test('Fungsi sum menambahkan dua angka dengan benar', () => {
  // Test case 1: Penjumlahan dua angka positif
  assert.strictEqual(sum(2, 3), 5, 'Penjumlahan 2 dan 3 harusnya 5');
  
  // Test case 2: Penjumlahan angka positif dan nol
  assert.strictEqual(sum(10, 0), 10, 'Penjumlahan 10 dan 0 harusnya 10');
  
  // Test case 3: Penjumlahan angka negatif dan positif
  assert.strictEqual(sum(-5, 5), 0, 'Penjumlahan -5 dan 5 harusnya 0');
  
  // Test case 4: Penjumlahan dua angka negatif
  assert.strictEqual(sum(-3, -7), -10, 'Penjumlahan -3 dan -7 harusnya -10');
});
